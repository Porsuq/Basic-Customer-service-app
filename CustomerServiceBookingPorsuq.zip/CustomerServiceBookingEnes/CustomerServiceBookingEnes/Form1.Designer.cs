﻿namespace CustomerServiceBookingEnes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnAppointmentList = new System.Windows.Forms.Button();
            this.btnCreateAppointment = new System.Windows.Forms.Button();
            this.btnRegisteredCustomer = new System.Windows.Forms.Button();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.pnlAddCustomer = new System.Windows.Forms.Panel();
            this.txtPNumber = new System.Windows.Forms.RichTextBox();
            this.txtLName = new System.Windows.Forms.RichTextBox();
            this.txtFName = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnSaveCustomer = new System.Windows.Forms.Button();
            this.pnlCustomerList = new System.Windows.Forms.Panel();
            this.lblCustomerListError = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtInputID = new System.Windows.Forms.RichTextBox();
            this.listViewCustomers = new System.Windows.Forms.ListView();
            this.clmID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmFName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmLName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmCNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSearchCustomer = new System.Windows.Forms.Button();
            this.btnViewCustomers = new System.Windows.Forms.Button();
            this.btnListBack = new System.Windows.Forms.Button();
            this.pnlCreateAppointment = new System.Windows.Forms.Panel();
            this.cmbServices = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtUserID = new System.Windows.Forms.RichTextBox();
            this.btnSaveAppointment = new System.Windows.Forms.Button();
            this.btnCAptBack = new System.Windows.Forms.Button();
            this.lblAppointmentError = new System.Windows.Forms.Label();
            this.dateAppointment = new System.Windows.Forms.MonthCalendar();
            this.pnlViewAppointments = new System.Windows.Forms.Panel();
            this.listViewAppointments = new System.Windows.Forms.ListView();
            this.clmCustomerIDAPP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmServiceAPP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmDateAPP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnAppointmentListBack = new System.Windows.Forms.Button();
            this.btnViewAppointmentList = new System.Windows.Forms.Button();
            this.pnlMenu.SuspendLayout();
            this.pnlAddCustomer.SuspendLayout();
            this.pnlCustomerList.SuspendLayout();
            this.pnlCreateAppointment.SuspendLayout();
            this.pnlViewAppointments.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMenu
            // 
            this.pnlMenu.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlMenu.Controls.Add(this.btnExit);
            this.pnlMenu.Controls.Add(this.btnAppointmentList);
            this.pnlMenu.Controls.Add(this.btnCreateAppointment);
            this.pnlMenu.Controls.Add(this.btnRegisteredCustomer);
            this.pnlMenu.Controls.Add(this.btnAddCustomer);
            this.pnlMenu.Location = new System.Drawing.Point(12, 23);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(1389, 596);
            this.pnlMenu.TabIndex = 0;
            this.pnlMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMenu_Paint);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Brown;
            this.btnExit.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(509, 407);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(396, 77);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnAppointmentList
            // 
            this.btnAppointmentList.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnAppointmentList.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppointmentList.Location = new System.Drawing.Point(509, 324);
            this.btnAppointmentList.Name = "btnAppointmentList";
            this.btnAppointmentList.Size = new System.Drawing.Size(396, 77);
            this.btnAppointmentList.TabIndex = 0;
            this.btnAppointmentList.Text = "Appointment List";
            this.btnAppointmentList.UseVisualStyleBackColor = false;
            this.btnAppointmentList.Click += new System.EventHandler(this.btnAppointmentList_click);
            // 
            // btnCreateAppointment
            // 
            this.btnCreateAppointment.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnCreateAppointment.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateAppointment.Location = new System.Drawing.Point(509, 241);
            this.btnCreateAppointment.Name = "btnCreateAppointment";
            this.btnCreateAppointment.Size = new System.Drawing.Size(396, 77);
            this.btnCreateAppointment.TabIndex = 0;
            this.btnCreateAppointment.Text = "Create Appointment";
            this.btnCreateAppointment.UseVisualStyleBackColor = false;
            this.btnCreateAppointment.Click += new System.EventHandler(this.btnCreateAppointment_Click);
            // 
            // btnRegisteredCustomer
            // 
            this.btnRegisteredCustomer.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnRegisteredCustomer.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegisteredCustomer.Location = new System.Drawing.Point(509, 158);
            this.btnRegisteredCustomer.Name = "btnRegisteredCustomer";
            this.btnRegisteredCustomer.Size = new System.Drawing.Size(396, 77);
            this.btnRegisteredCustomer.TabIndex = 0;
            this.btnRegisteredCustomer.Text = "Registered Customers";
            this.btnRegisteredCustomer.UseVisualStyleBackColor = false;
            this.btnRegisteredCustomer.Click += new System.EventHandler(this.btnRegisteredCustomer_Click);
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnAddCustomer.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCustomer.Location = new System.Drawing.Point(509, 75);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(396, 77);
            this.btnAddCustomer.TabIndex = 0;
            this.btnAddCustomer.Text = "Add Customer";
            this.btnAddCustomer.UseVisualStyleBackColor = false;
            this.btnAddCustomer.Click += new System.EventHandler(this.btnAddCustomer_Click);
            // 
            // pnlAddCustomer
            // 
            this.pnlAddCustomer.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlAddCustomer.Controls.Add(this.txtPNumber);
            this.pnlAddCustomer.Controls.Add(this.txtLName);
            this.pnlAddCustomer.Controls.Add(this.txtFName);
            this.pnlAddCustomer.Controls.Add(this.label3);
            this.pnlAddCustomer.Controls.Add(this.label2);
            this.pnlAddCustomer.Controls.Add(this.label1);
            this.pnlAddCustomer.Controls.Add(this.btnReset);
            this.pnlAddCustomer.Controls.Add(this.btnBack);
            this.pnlAddCustomer.Controls.Add(this.btnSaveCustomer);
            this.pnlAddCustomer.Enabled = false;
            this.pnlAddCustomer.Location = new System.Drawing.Point(12, 23);
            this.pnlAddCustomer.Name = "pnlAddCustomer";
            this.pnlAddCustomer.Size = new System.Drawing.Size(1389, 596);
            this.pnlAddCustomer.TabIndex = 1;
            this.pnlAddCustomer.Visible = false;
            // 
            // txtPNumber
            // 
            this.txtPNumber.Location = new System.Drawing.Point(637, 245);
            this.txtPNumber.Name = "txtPNumber";
            this.txtPNumber.Size = new System.Drawing.Size(268, 53);
            this.txtPNumber.TabIndex = 2;
            this.txtPNumber.Text = "";
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(637, 145);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(268, 53);
            this.txtLName.TabIndex = 2;
            this.txtLName.Text = "";
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(637, 75);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(268, 53);
            this.txtFName.TabIndex = 2;
            this.txtFName.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(428, 272);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Phone-Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(428, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(428, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "First Name";
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(538, 463);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(259, 77);
            this.btnReset.TabIndex = 0;
            this.btnReset.Text = "Reset Details";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.LightCoral;
            this.btnBack.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(244, 463);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(259, 77);
            this.btnBack.TabIndex = 0;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnSaveCustomer
            // 
            this.btnSaveCustomer.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveCustomer.Location = new System.Drawing.Point(824, 463);
            this.btnSaveCustomer.Name = "btnSaveCustomer";
            this.btnSaveCustomer.Size = new System.Drawing.Size(259, 77);
            this.btnSaveCustomer.TabIndex = 0;
            this.btnSaveCustomer.Text = "Save Customer Details";
            this.btnSaveCustomer.UseVisualStyleBackColor = true;
            this.btnSaveCustomer.Click += new System.EventHandler(this.btnSaveCustomer_Click);
            // 
            // pnlCustomerList
            // 
            this.pnlCustomerList.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCustomerList.Controls.Add(this.lblCustomerListError);
            this.pnlCustomerList.Controls.Add(this.label5);
            this.pnlCustomerList.Controls.Add(this.txtInputID);
            this.pnlCustomerList.Controls.Add(this.listViewCustomers);
            this.pnlCustomerList.Controls.Add(this.btnSearchCustomer);
            this.pnlCustomerList.Controls.Add(this.btnViewCustomers);
            this.pnlCustomerList.Controls.Add(this.btnListBack);
            this.pnlCustomerList.Enabled = false;
            this.pnlCustomerList.Location = new System.Drawing.Point(12, 20);
            this.pnlCustomerList.Name = "pnlCustomerList";
            this.pnlCustomerList.Size = new System.Drawing.Size(1389, 596);
            this.pnlCustomerList.TabIndex = 1;
            this.pnlCustomerList.Visible = false;
            this.pnlCustomerList.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlCustomerList_Paint);
            // 
            // lblCustomerListError
            // 
            this.lblCustomerListError.AutoSize = true;
            this.lblCustomerListError.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerListError.ForeColor = System.Drawing.Color.Brown;
            this.lblCustomerListError.Location = new System.Drawing.Point(1020, 175);
            this.lblCustomerListError.Name = "lblCustomerListError";
            this.lblCustomerListError.Size = new System.Drawing.Size(0, 20);
            this.lblCustomerListError.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1156, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Enter Customer ID";
            // 
            // txtInputID
            // 
            this.txtInputID.Location = new System.Drawing.Point(1019, 100);
            this.txtInputID.Name = "txtInputID";
            this.txtInputID.Size = new System.Drawing.Size(131, 26);
            this.txtInputID.TabIndex = 3;
            this.txtInputID.Text = "";
            // 
            // listViewCustomers
            // 
            this.listViewCustomers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmID,
            this.clmFName,
            this.clmLName,
            this.clmCNum});
            this.listViewCustomers.HideSelection = false;
            this.listViewCustomers.Location = new System.Drawing.Point(343, 89);
            this.listViewCustomers.Name = "listViewCustomers";
            this.listViewCustomers.Size = new System.Drawing.Size(671, 371);
            this.listViewCustomers.TabIndex = 2;
            this.listViewCustomers.UseCompatibleStateImageBehavior = false;
            this.listViewCustomers.View = System.Windows.Forms.View.Details;
            // 
            // clmID
            // 
            this.clmID.Text = "ID";
            this.clmID.Width = 100;
            // 
            // clmFName
            // 
            this.clmFName.Text = "FirstName";
            this.clmFName.Width = 159;
            // 
            // clmLName
            // 
            this.clmLName.Text = "LastName";
            this.clmLName.Width = 150;
            // 
            // clmCNum
            // 
            this.clmCNum.Text = "PhoneNumber";
            this.clmCNum.Width = 150;
            // 
            // btnSearchCustomer
            // 
            this.btnSearchCustomer.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnSearchCustomer.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchCustomer.Location = new System.Drawing.Point(1019, 132);
            this.btnSearchCustomer.Name = "btnSearchCustomer";
            this.btnSearchCustomer.Size = new System.Drawing.Size(260, 39);
            this.btnSearchCustomer.TabIndex = 1;
            this.btnSearchCustomer.Text = "Search Customer";
            this.btnSearchCustomer.UseVisualStyleBackColor = false;
            this.btnSearchCustomer.Click += new System.EventHandler(this.btnSearchCustomer_Click);
            // 
            // btnViewCustomers
            // 
            this.btnViewCustomers.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnViewCustomers.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewCustomers.Location = new System.Drawing.Point(755, 466);
            this.btnViewCustomers.Name = "btnViewCustomers";
            this.btnViewCustomers.Size = new System.Drawing.Size(259, 77);
            this.btnViewCustomers.TabIndex = 1;
            this.btnViewCustomers.Text = "View Customers";
            this.btnViewCustomers.UseVisualStyleBackColor = false;
            this.btnViewCustomers.Click += new System.EventHandler(this.btnListViewCustomers_Click);
            // 
            // btnListBack
            // 
            this.btnListBack.BackColor = System.Drawing.Color.LightCoral;
            this.btnListBack.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListBack.Location = new System.Drawing.Point(343, 466);
            this.btnListBack.Name = "btnListBack";
            this.btnListBack.Size = new System.Drawing.Size(259, 77);
            this.btnListBack.TabIndex = 1;
            this.btnListBack.Text = "Back";
            this.btnListBack.UseVisualStyleBackColor = false;
            this.btnListBack.Click += new System.EventHandler(this.btnListBack_Click);
            // 
            // pnlCreateAppointment
            // 
            this.pnlCreateAppointment.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCreateAppointment.Controls.Add(this.dateAppointment);
            this.pnlCreateAppointment.Controls.Add(this.lblAppointmentError);
            this.pnlCreateAppointment.Controls.Add(this.cmbServices);
            this.pnlCreateAppointment.Controls.Add(this.label4);
            this.pnlCreateAppointment.Controls.Add(this.txtUserID);
            this.pnlCreateAppointment.Controls.Add(this.btnSaveAppointment);
            this.pnlCreateAppointment.Controls.Add(this.btnCAptBack);
            this.pnlCreateAppointment.Enabled = false;
            this.pnlCreateAppointment.Location = new System.Drawing.Point(15, 20);
            this.pnlCreateAppointment.Name = "pnlCreateAppointment";
            this.pnlCreateAppointment.Size = new System.Drawing.Size(1389, 596);
            this.pnlCreateAppointment.TabIndex = 4;
            this.pnlCreateAppointment.Visible = false;
            // 
            // cmbServices
            // 
            this.cmbServices.FormattingEnabled = true;
            this.cmbServices.Items.AddRange(new object[] {
            "HairCut",
            "Shave",
            "HairDye",
            "KidsCut"});
            this.cmbServices.Location = new System.Drawing.Point(258, 73);
            this.cmbServices.Name = "cmbServices";
            this.cmbServices.Size = new System.Drawing.Size(606, 21);
            this.cmbServices.TabIndex = 5;
            this.cmbServices.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1112, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "UserID";
            // 
            // txtUserID
            // 
            this.txtUserID.Location = new System.Drawing.Point(993, 71);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Size = new System.Drawing.Size(113, 22);
            this.txtUserID.TabIndex = 3;
            this.txtUserID.Text = "";
            // 
            // btnSaveAppointment
            // 
            this.btnSaveAppointment.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnSaveAppointment.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveAppointment.Location = new System.Drawing.Point(899, 466);
            this.btnSaveAppointment.Name = "btnSaveAppointment";
            this.btnSaveAppointment.Size = new System.Drawing.Size(256, 77);
            this.btnSaveAppointment.TabIndex = 2;
            this.btnSaveAppointment.Text = "Save Appointment Details";
            this.btnSaveAppointment.UseVisualStyleBackColor = false;
            this.btnSaveAppointment.Click += new System.EventHandler(this.btnSaveAppointment_click);
            // 
            // btnCAptBack
            // 
            this.btnCAptBack.BackColor = System.Drawing.Color.LightCoral;
            this.btnCAptBack.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCAptBack.Location = new System.Drawing.Point(258, 466);
            this.btnCAptBack.Name = "btnCAptBack";
            this.btnCAptBack.Size = new System.Drawing.Size(259, 77);
            this.btnCAptBack.TabIndex = 2;
            this.btnCAptBack.Text = "Back";
            this.btnCAptBack.UseVisualStyleBackColor = false;
            this.btnCAptBack.Click += new System.EventHandler(this.btnCAptBack_Click);
            // 
            // lblAppointmentError
            // 
            this.lblAppointmentError.AutoSize = true;
            this.lblAppointmentError.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAppointmentError.ForeColor = System.Drawing.Color.Firebrick;
            this.lblAppointmentError.Location = new System.Drawing.Point(993, 109);
            this.lblAppointmentError.Name = "lblAppointmentError";
            this.lblAppointmentError.Size = new System.Drawing.Size(0, 16);
            this.lblAppointmentError.TabIndex = 6;
            // 
            // dateAppointment
            // 
            this.dateAppointment.CalendarDimensions = new System.Drawing.Size(3, 2);
            this.dateAppointment.Location = new System.Drawing.Point(258, 114);
            this.dateAppointment.Name = "dateAppointment";
            this.dateAppointment.TabIndex = 7;
            // 
            // pnlViewAppointments
            // 
            this.pnlViewAppointments.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlViewAppointments.Controls.Add(this.btnViewAppointmentList);
            this.pnlViewAppointments.Controls.Add(this.btnAppointmentListBack);
            this.pnlViewAppointments.Controls.Add(this.listViewAppointments);
            this.pnlViewAppointments.Location = new System.Drawing.Point(12, 20);
            this.pnlViewAppointments.Name = "pnlViewAppointments";
            this.pnlViewAppointments.Size = new System.Drawing.Size(1392, 599);
            this.pnlViewAppointments.TabIndex = 1;
            // 
            // listViewAppointments
            // 
            this.listViewAppointments.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmCustomerIDAPP,
            this.clmServiceAPP,
            this.clmDateAPP});
            this.listViewAppointments.HideSelection = false;
            this.listViewAppointments.Location = new System.Drawing.Point(252, 46);
            this.listViewAppointments.Name = "listViewAppointments";
            this.listViewAppointments.Size = new System.Drawing.Size(906, 414);
            this.listViewAppointments.TabIndex = 0;
            this.listViewAppointments.UseCompatibleStateImageBehavior = false;
            this.listViewAppointments.View = System.Windows.Forms.View.Details;
            this.listViewAppointments.SelectedIndexChanged += new System.EventHandler(this.listViewAppointments_SelectedIndexChanged);
            // 
            // clmCustomerIDAPP
            // 
            this.clmCustomerIDAPP.Text = "Customer ID";
            this.clmCustomerIDAPP.Width = 100;
            // 
            // clmServiceAPP
            // 
            this.clmServiceAPP.Text = "Service";
            this.clmServiceAPP.Width = 150;
            // 
            // clmDateAPP
            // 
            this.clmDateAPP.Text = "Appointment Date";
            this.clmDateAPP.Width = 400;
            // 
            // btnAppointmentListBack
            // 
            this.btnAppointmentListBack.BackColor = System.Drawing.Color.LightCoral;
            this.btnAppointmentListBack.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppointmentListBack.Location = new System.Drawing.Point(252, 493);
            this.btnAppointmentListBack.Name = "btnAppointmentListBack";
            this.btnAppointmentListBack.Size = new System.Drawing.Size(259, 77);
            this.btnAppointmentListBack.TabIndex = 2;
            this.btnAppointmentListBack.Text = "Back";
            this.btnAppointmentListBack.UseVisualStyleBackColor = false;
            this.btnAppointmentListBack.Click += new System.EventHandler(this.btnAppointmentListBack_Click);
            // 
            // btnViewAppointmentList
            // 
            this.btnViewAppointmentList.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnViewAppointmentList.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewAppointmentList.Location = new System.Drawing.Point(902, 493);
            this.btnViewAppointmentList.Name = "btnViewAppointmentList";
            this.btnViewAppointmentList.Size = new System.Drawing.Size(259, 77);
            this.btnViewAppointmentList.TabIndex = 2;
            this.btnViewAppointmentList.Text = "View Appointments";
            this.btnViewAppointmentList.UseVisualStyleBackColor = false;
            this.btnViewAppointmentList.Click += new System.EventHandler(this.btnViewAppointmentList_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1413, 631);
            this.Controls.Add(this.pnlCreateAppointment);
            this.Controls.Add(this.pnlCustomerList);
            this.Controls.Add(this.pnlViewAppointments);
            this.Controls.Add(this.pnlMenu);
            this.Controls.Add(this.pnlAddCustomer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnlMenu.ResumeLayout(false);
            this.pnlAddCustomer.ResumeLayout(false);
            this.pnlAddCustomer.PerformLayout();
            this.pnlCustomerList.ResumeLayout(false);
            this.pnlCustomerList.PerformLayout();
            this.pnlCreateAppointment.ResumeLayout(false);
            this.pnlCreateAppointment.PerformLayout();
            this.pnlViewAppointments.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.Button btnAppointmentList;
        private System.Windows.Forms.Button btnCreateAppointment;
        private System.Windows.Forms.Button btnRegisteredCustomer;
        private System.Windows.Forms.Button btnAddCustomer;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Panel pnlAddCustomer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnSaveCustomer;
        private System.Windows.Forms.RichTextBox txtPNumber;
        private System.Windows.Forms.RichTextBox txtLName;
        private System.Windows.Forms.RichTextBox txtFName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlCustomerList;
        private System.Windows.Forms.Button btnListBack;
        private System.Windows.Forms.ListView listViewCustomers;
        private System.Windows.Forms.ColumnHeader clmID;
        private System.Windows.Forms.ColumnHeader clmFName;
        private System.Windows.Forms.ColumnHeader clmLName;
        private System.Windows.Forms.ColumnHeader clmCNum;
        private System.Windows.Forms.Button btnViewCustomers;
        private System.Windows.Forms.RichTextBox txtInputID;
        private System.Windows.Forms.Button btnSearchCustomer;
        private System.Windows.Forms.Panel pnlCreateAppointment;
        private System.Windows.Forms.Button btnCAptBack;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox txtUserID;
        private System.Windows.Forms.Button btnSaveAppointment;
        private System.Windows.Forms.Label lblCustomerListError;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbServices;
        private System.Windows.Forms.Label lblAppointmentError;
        private System.Windows.Forms.MonthCalendar dateAppointment;
        private System.Windows.Forms.Panel pnlViewAppointments;
        private System.Windows.Forms.ListView listViewAppointments;
        private System.Windows.Forms.ColumnHeader clmCustomerIDAPP;
        private System.Windows.Forms.ColumnHeader clmServiceAPP;
        private System.Windows.Forms.ColumnHeader clmDateAPP;
        private System.Windows.Forms.Button btnAppointmentListBack;
        private System.Windows.Forms.Button btnViewAppointmentList;
    }
}

