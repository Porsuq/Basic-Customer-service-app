﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CustomerServiceBookingEnes
{
    public partial class Form1 : Form
    {
        //Data list for customers
        public List<Customer> Customers = new List<Customer>();
        public List<Appointment> Appointments = new List<Appointment>();

        public int test = 0;


        //This helps with customerID count as, if we called CID++; it would always be 1 when saved as* when we get CID from the customer class it always starts with 0
        public int CustomerID;
        public string CustomerStrID;

        public Form1()
        {
            InitializeComponent();

        }
        //In order to create a proper list, apparently create a custom class help with the list table. As 
        public class Customer 
        {
            public string CFname;
            public string CLname;
            public string CPnum;
            public string CID;
        }

        public class Appointment
        {
            public string service;
            public string customerAppointmentID;
            public string appointmentDate;
        }

        public void NewAppointment(string Service, string CustomerID, string AppointmentDate)
        {

            Appointment AddNewAppointment = new Appointment();
            AddNewAppointment.service = Service;
            AddNewAppointment.customerAppointmentID = CustomerID;
            AddNewAppointment.appointmentDate = AppointmentDate;

            Appointments.Add(AddNewAppointment);

        }

        public void NewCustomer(string FName, string LName, string PNum)
        {
            Customer AddNewCustomer = new Customer();
            AddNewCustomer.CFname = FName;
            AddNewCustomer.CLname = LName;
            AddNewCustomer.CPnum = PNum;


            CustomerStrID = Convert.ToString(CustomerID);
            AddNewCustomer.CID = CustomerStrID;

            Console.WriteLine($"{AddNewCustomer.CFname} + {AddNewCustomer.CLname} + {AddNewCustomer.CPnum} + {AddNewCustomer.CID}");

            Customers.Add(AddNewCustomer);
            CustomerID++;
        }








        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to exit the program?", "Attention", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }




        private void pnlMenu_Paint(object sender, PaintEventArgs e)
        {

        }





        //Switches between Panel
        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            //Makes the menu Invisible and de-activates all functionalities
            pnlMenu.Visible = false;
            pnlMenu.Enabled = false;
            //Makes Customer adding panel visible and makes it functionalities usable/active 
            pnlAddCustomer.Visible = true;
            pnlAddCustomer.Enabled = true;
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            pnlMenu.Visible = true;
            pnlMenu.Enabled = true;
            pnlAddCustomer.Visible = false;
            pnlAddCustomer.Enabled = false;
        }
        private void btnCAptBack_Click(object sender, EventArgs e)
        {
            pnlMenu.Visible = true;
            pnlMenu.Enabled = true;
            pnlCreateAppointment.Visible = false;
            pnlCreateAppointment.Enabled = false;
        }
        private void btnListBack_Click(object sender, EventArgs e)
        {
            pnlMenu.Visible = true;
            pnlMenu.Enabled = true;
            pnlCustomerList.Visible = false;
            pnlCustomerList.Enabled = false;
        }

        private void btnRegisteredCustomer_Click(object sender, EventArgs e)
        {
            pnlMenu.Visible = false;
            pnlMenu.Enabled = false;
            pnlCustomerList.Visible = true;
            pnlCustomerList.Enabled = true;
        }
        private void btnCreateAppointment_Click(object sender, EventArgs e)
        {
            pnlMenu.Visible = false;
            pnlMenu.Enabled = false;
            pnlCreateAppointment.Visible = true;
            pnlCreateAppointment.Enabled = true;
        }
        private void btnAppointmentListBack_Click(object sender, EventArgs e)
        {
            pnlViewAppointments.Visible = false;
            pnlViewAppointments.Enabled = false;
            pnlMenu.Visible = true;
            pnlMenu.Enabled = true;
        }
        private void btnAppointmentList_click(object sender, EventArgs e)
        {
            pnlMenu.Visible = false;
            pnlMenu.Enabled = false;
            pnlViewAppointments.Visible = true;
            pnlViewAppointments.Enabled = true;
        }



        //Saving new customer details
        private void btnSaveCustomer_Click(object sender, EventArgs e)
        {
            //Checking if name is only made of letters and the length is correct
            if (txtFName.Text.All(char.IsLetter) && txtFName.Text.Length > 3 && txtFName.Text.Length < 18)
            {
                //Checking if last name is only made of letters and the length is correct
                if (txtLName.Text.All(char.IsLetter) && txtLName.Text.Length > 3 && txtLName.Text.Length < 18)
                {
                    //Checking if phone number is only made out of digits and the length is correct
                    if (txtPNumber.Text.All(char.IsDigit) && txtPNumber.Text.Length == 10)
                    {
                        NewCustomer(txtFName.Text, txtLName.Text, txtPNumber.Text);
                        txtFName.Text = "";
                        txtLName.Text = "";
                        txtPNumber.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Please Make sure that the phone number is 10 digit number and that it's only numbers.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }
                else
                {
                    MessageBox.Show("Please Make sure the Last Name is more than 3 letters, less than 18 and that you are using only letters.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please Make sure the First Name is more than 3 letters, less than 18 and that you are using only letters.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Resetting all details in Adding new customer panel
        private void btnReset_Click(object sender, EventArgs e)
        {
            txtFName.Text = "";
            txtLName.Text = "";
            txtPNumber.Text = "";

        }


        //This button displays all customers
        private void btnListViewCustomers_Click(object sender, EventArgs e)
        {
           listViewCustomers.Items.Clear();
           foreach (var i in Customers)
            {
                ListViewItem lv1 = new ListViewItem(Customers[test].CID);
                lv1.SubItems.Add(Customers[test].CFname);
                lv1.SubItems.Add(Customers[test].CLname);
                lv1.SubItems.Add(Customers[test].CPnum);

                listViewCustomers.Items.Add(lv1);
                test++;
           } 
           //Clears up the list every time this button is clicked, otherwise the list would be a long list of the same users
            
            test = 0;
            Console.WriteLine("This Button is working");
        }

        private void listViewCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //System to search for customer details with their specific ID
        private void btnSearchCustomer_Click(object sender, EventArgs e)
        {
            lblCustomerListError.Text = "";
            try
            {
                listViewCustomers.Items.Clear();
                int id;
                id = Convert.ToInt32(txtInputID.Text);

                ListViewItem lv1 = new ListViewItem(Customers[id].CID);
                lv1.SubItems.Add(Customers[id].CFname);
                lv1.SubItems.Add(Customers[id].CLname);
                lv1.SubItems.Add(Customers[id].CPnum);

                listViewCustomers.Items.Add(lv1);
            }
            catch (Exception) 
            {
                lblCustomerListError.Text = "The ID you have entered was incorrect, try again.";
            }

        }

        private void pnlCustomerList_Paint(object sender, PaintEventArgs e)
        {

        }


        //Button to save appointment details for customers
        private void btnSaveAppointment_click (object sender, EventArgs e)
        {

            try
            {
                if (dateAppointment.SelectionStart > DateTime.Now)
                {
                    int id = Convert.ToInt32(txtUserID.Text);
                    if (txtUserID.Text == Customers[id].CID)
                    {
                        if (cmbServices.SelectedIndex != -1) 
                        {
                            string appDate = Convert.ToString(dateAppointment.SelectionStart);
                            NewAppointment(cmbServices.Text, txtUserID.Text, appDate);
                            Console.WriteLine(cmbServices.Text + " + " + txtUserID.Text + " + " + dateAppointment.SelectionStart);
                            Console.WriteLine("This is supposed to be the date printing" + appDate);

                        }
                        else
                        {
                            MessageBox.Show("You must Choose a service for that appointment", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }


                }
                else
                {
                    //lblAppointmentError.Text = "Appointment was not created \n, the date has to be greater than the current date.";
                    MessageBox.Show("Appointment was not created , the date has to be greater than the current date.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                    


            }
            catch (Exception)
            {
                MessageBox.Show("Appointment was not created, the Customer ID is incorrect or something else went wrong.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
               
            }
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listViewAppointments_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        //Listing all appointments
        private void btnViewAppointmentList_Click(object sender, EventArgs e)
        {
            listViewAppointments.Items.Clear();
            foreach (var i in Appointments)
            {
                ListViewItem listingAppointments = new ListViewItem(Appointments[test].customerAppointmentID);
                listingAppointments.SubItems.Add(Appointments[test].service);
                listingAppointments.SubItems.Add(Appointments[test].appointmentDate);

                listViewAppointments.Items.Add(listingAppointments);

                test++;
            }
            test = 0;

        }
    }
}
